# C2: one synthetic practitioner controller and two existing Web panels

Status: implementation admission requested; no C2 runtime file or HTML change has been made. This is the next bounded step after independently accepted C1, not authorization to activate C3.

## 1. Fixed baseline and observed source

- C1 archive: `snapshots/web-registration-c1-reviewed-20261022T0221Z.tar.gz`, SHA256 `4473f8395a2428e38785a4e1383ea1d3cf2273133e83b0ce7aee46ff74836593`. Eight runtime hashes are in `../batch-c/SOURCE-MANIFEST.json`; independent report SHA256 `aa76d8b768e19d9a09042f2973d35177a2824294a75eb10594779a3dfce5450d`. Final independent C1 208/208 includes the same 189 candidate tests plus 19 independent probes; overlap is not added as feature coverage.
- B core `24300fa7…`, adapter `61579ddc…`, kernel `3a5426c…` remain frozen. The kernel contains the six byte-pinned native modules, including registration schema/bridge and pure forms. Native frozen HEAD remains `bf0f884c578e26e6cd4325f6f2b97bee11b1a0e7`; this batch cannot edit it.
- Actual `pages/student.html` has two roots: `#practitioner-root` and `#registration > #platform-root`, `student.css`, CSP `connect-src 'none'` and no inline scripts. Its current script graph is old core → raw practitioner A → old relationship UI → platform model → synthetic B → old registration UI. It remains unchanged during C2.
- Old `pages/practitioner-ui.js` owns one A session, directory/topics, inquiries, invitations, private-client summary and filters. It also exposes raw service/fixture/failure controls, has independent role selection, and subscribes to reconciliation outside the new entry operation gate. These writer paths cannot be reused.
- Old `pages/student-platform.js` creates an unrelated B in-memory owner Map and controller. Its complete seven-field registration and seven-field article forms, error presentation and existing CSS/layout are reusable; its memory owner selection, fixture approval/revocation and independent pending state are not. Old B records were never durably persisted and cannot be recovered by this migration.
- Reviewed native `synthetic/practitioner-forms.js` supplies `decorate/open/present/sample/save/request/review`, exact author/reviewer targets, synthetic claim-reference restriction, explicit synthetic acknowledgment and seven-field validation. Reuse these via the unchanged kernel; do not recreate the state machine, derive new review semantics, or expose vendor B.fixture.
- B's actual service methods return `{context,view,committed,persistent,viewExpiresAt,...}`. Every command already includes a same-commit view. `relationship` is null for the reviewer. B's deadline covers all qualifications considered valid in its candidate, including reviewer/publication cases. Do not compute a narrower deadline from a client directory.

## 2. Exact runtime scope and graph

Only these three NEW JavaScript files are permitted, with tests/documents under this batch directory:

| File | Responsibility |
| --- | --- |
| `pages/practitioner-controller-v3.js` (PC) | One shared controller, private E-wrapped service/session, full context/deadline/operation/editor lifetimes, strict action construction and projection. |
| `pages/practitioner-ui-v3.js` (PU) | Existing directory/workbench/public article surface, one role chooser, guarded event bindings. |
| `pages/student-platform-v3.js` (SP) | Existing full registration/article editor and reviewer surface using kernel forms, guarded event bindings. |

No C1 runtime, B source, native module, old page/model/CSS, HTML, storage key/schema, seed, remote API, credential or service is changed. Use existing `student.css` classes and common C1 entry CSS. If these boundaries are insufficient, stop and revise scope rather than silently widening it.

The later proposed student graph remains the approved common seven scripts followed by PC → PU → SP. Each completes its factory before registering its exact `registration-web-v3-c1` tail (`practitioner-controller`, `practitioner-ui`, `student-platform`) with E. PC installs one instance keyed to that E instance; PU/SP attach renderers to it, not independent controllers. Missing roots/incorrect factories cause synchronous mount failure before E can adopt. All three actual mount definitions are checked before child startup. No work starts during script evaluation, no raw A/B runtime is loaded, and there is no compatibility fallback.

C2 tests may load the actual new scripts into an in-memory proposed student document with the existing two roots and stylesheet structure. Such tests prove the proposed graph only. The real twelve HTML scripts and body marker are changed and tested separately at C3.

## 3. Controller and renderer contract

PC exports a versioned factory and an entry-bound accessor for PU/SP; the controller is not a globally exported raw service. Test factories accept injected clock/ID/DOM environment; production uses normal clock and crypto random IDs. Missing valid key generation fails before write.

Public controller operations are semantic and validate their tickets: initialize/retryInitialize, refresh, choosePersona/logout, selectPractitioner/topic/consent/filter/tab, openForm/changeField/ack/sample/save/cancel, requestAction, reviewAction, relationshipAction, confirmNavigation, subscribe/render attachment, dispose. Return snapshots are detached/frozen presentation values. No session, lease, original service, account, journal mutator or mutable pending capability is exposed.

One controller owns:

- Page lifetime epoch, initialization attempt, role/session epoch and operation sequence;
- the selected persona, one verified view with full six-field context, earliest deadline and local render sequence;
- one optional form (kind, target owner/ID, original version, registration epoch, original full Web context, form serial, values, acknowledgment, dirty/errors);
- relationship draft (selected practitioner ID AND qualification revision, topic, consent); filters/tabs are display-only;
- one frozen submitted envelope retained by E; any local reference is for presentation/reconciliation only and cannot be used to create a new key or rebase an unknown request.

Both renderers attach stable root event listeners once, and detach them on disposal. They do not independently read/reconcile/persist, own actor sessions, mount a second controller or subscribe to domain storage. No legacy 30-second write loop and no second BFCache reload handler is copied; E owns BFCache reload. PC may schedule one local deadline invalidation timer, which disables current authorization without issuing a hidden snapshot/write.

## 4. Service leases, actual calls, and operation envelopes

Every asynchronous service call, INCLUDING initial/refresh snapshot, is inside `E.execute`:

1. Capture immutable Page/session/form or action tickets and current displayed business context before the first await. Validate complete Web context `{mode,accountId,protocolVersion,epoch,generation,revision}`. Native four-field `contract.intent` cannot validate or replace it.
2. Capture exact payload and a 16–80-character schema-valid operation key. Freeze input/key/full business intent. UI names/DOM values are not permission; re-find the displayed target and validate role/flags/version before constructing the payload.
3. `E.execute({kind,context,input,guard,run,onSuccess,onError,reconcile})` creates its private lease. `run({input,context,lease})` calls ONLY the wrapped `service.snapshot(session,lease)`, `request(session,input.payload,input.key,context,lease)`, `review(...)` or `command(...)`.
4. `guard` binds Page/session/operation lifetime and full account identity excluding revision, so genuine same-epoch durable receipt replay remains possible. First dispatch separately requires exact displayed revision; B handles a retained original intent on replay. No later `store.context()` fallback upgrades a business request.
5. Commands use their returned same-commit view. Do not issue a redundant second snapshot after success, reuse an already settled lease, or pretend a later unrelated snapshot proves the original command committed.

Snapshots may normalize expiry or enroll a legacy journal. They use a current captured context for E execution, but have no fabricated business receipt/key. A failed snapshot may itself have an unknown outcome and uses the same E pending gate. A new refresh cannot bypass that gate.

E's original operation persists while unknown. Retry always uses the original service/session, payload, key and intent; only E may reactivate its original lease. Completed/forged/missing leases cannot reach B. E Stop discards local retry authority only; it does not undo a write or discard a registration form. PC observes E status changes so safe refresh/retry-initialization becomes reachable after Stop, without re-enabling stale Save.

## 5. Atomic presentation and final freshness

A service result is not permission to paint by itself. PC builds a detached projected candidate, then prepares BOTH renderer outputs without changing displayed state or editor ownership. Immediately before synchronous DOM presentation it checks:

- Page is visible/alive; initialization, role/session and operation/refresh sequences still match;
- current E phase/lifetime and all six current root context fields exactly match returned context;
- `result.view.context` equals the returned full context;
- current clock is valid, has not gone backwards within this controller, and is strictly before non-null `viewExpiresAt`;
- returned identity matches the selected persona, and author/reviewer/client projections obey the expected role.

The current-root read used for the last context check may supply only whitelisted author display names and journal count at the SAME revision; never label an old view with a new context. Public author names are only `displayName` from the same-revision owner whitelist, with kernel's fixed fictional owner label as fallback. Neither full profile nor credential material is attached to public cards.

Renderers prepare escaped strings/detached fragments; their commit is synchronous, with no awaits or fresh domain reads. Controller state, context, render token and editor-close/clear changes commit only after both roots present successfully. If preparation, final read, deadline check or DOM commit fails, retain the previous editor DOM/value/base/ticket and show an explicit recovery message. If the first root commits and the second root throws, restore the exact saved old DOM nodes, not an innerHTML reconstruction. Retain runtime input.value/checkbox.checked that were never reflected to HTML attributes, focus/selection where modeled, form serial/base and controller state. Stable delegated listeners must remain installed once. This rollback applies to a same-role presentation attempt; it may not revive private content retired by an accepted identity change. Restoring old nodes/draft does not restore old authority: if the current root revision or deadline is no longer valid, the restored view stays read-only, old private authorization details remain hidden, and an independently guarded safe-refresh control stays reachable. This is UI rollback, not persistent rollback. Never announce refresh success or clear a known submitted form merely because an earlier read succeeded.

When a command was confirmed committed but its presentation is overtaken or fails, say the write was verified and current display needs refresh. Keep the old submitted draft/base read-only; do not mark it unsaved, reattach a newer context or auto-resend it. A successful final presentation may close the submitted editor once, but cannot clear a newer editor/draft.

Invalidation updates only safety/status controls and conceals active private authorization details. It preserves an existing form node and text until explicit successful refresh/cancel. Expired or stale displayed rows are marked unverified; they cannot keep enabled current authorization buttons. Every click also revalidates, so a delayed timer cannot authorize an expired operation. A snapshot in which all qualifications are already expired remains readable as unavailable; do not create a permanently past deadline from those entries.

## 6. Role and subscription arbitration

Five explicitly fictional personas: `client-a`, `client-b`, `fictional-lin`, `fictional-zhou`, `synthetic-reviewer`. PU owns the single chooser; SP shows that same current identity and links to the chooser. The initial role is client-a. This is a synthetic view switch, not authentication.

- Author sees only their registration/articles and their own demand workbench. Reviewer gets independent reviewer identity, empty relationship arrays, review queue and public articles. Clients get their own demand records/directory/public articles, no author/reviewer materials.
- A role change/logout or app-owned navigation first uses one combined `E.confirmLeave(dirty,message)` gate. Running operations cannot be interrupted into another mutation. Cancellation leaves selected role, DOM/draft, service/session and pending envelope unchanged; restore any already changed select value. Accepted choosePersona/logout stops pending retry explicitly and, BEFORE any await, retires role/session/editor/render tickets and clears both roots of the old actor label, private workbench/relationships, review queue, registration/profile and editor content. Only neutral loading/re-entry content may remain until the new role is verified. New login/snapshot/render failure must not restore old-role DOM or private values under the new identity. Only cancellation leaves the old role/content intact. Old callbacks cannot modify either panel. Never retain an old role as a capability after reset/restore.
- Store subscription compares the full account identity. Reset/restore/epoch/account changes synchronously retire Page-role operation authority, service/session, form and consent tokens before any await. Hide the previous actor label and all role-private content synchronously on account-identity retirement; do not expose an old author/reviewer draft to a later client persona. Default back to the client role only on deliberate re-entry. A transient read failure/corrupt state with NO accepted identity transition clears authority while retaining the same-role draft for recovery; it does not authorize identity replacement or imply reset is the repair.
- Same-identity revision changes invalidate display actions immediately. During the controller's own operation, do not dispose its session merely because its commit emitted; wait for its actual result and final presentation check. Foreign same-epoch writes can still overtake it and cause safe presentation failure.
- Ordinary refresh while a command is running is ignored/coalesced as a request for later user-visible refresh, never started in parallel. No stale refresh can win after a command. Reset/exit/pagehide still retire synchronously. Same-controller concurrent refresh is bounded; no unbounded retry loop.
- Explicit refresh asks once if there is a dirty form or pending unknown. Cancel preserves everything. Successful final presentation closes even a clean previously open editor; failure retains its original base. A clean old editor must not survive attached to a new view context.
- If a selected directory practitioner disappears or qualification revision changes, clear selected ID/revision and consent. Preserve topic if desired, but require selection and consent again. Already frozen pending envelopes are not edited by this reset.
- Browser native back/close can only receive best-effort beforeunload. Pagehide always disposes both surfaces/services and retires all callbacks. Page-only pending/key/session/undo state does not survive reload; no cross-reload resume promise.

## 7. Actual PU action map

PU preserves familiar page sections and anchors `#practitioner-directory`, `#practitioner-workbench`, `#registration`. Real service status always states disconnected, zero verified directory records; synthetic data is visibly separate. No real certificate/health/contact field is requested.

| Visible control | Exact controller/domain path and prerequisites |
| --- | --- |
| Choose / enter role, exit role | Local role/session transition with shared dirty/pending confirmation; no hidden domain write in login/logout. One subsequent snapshot through E. |
| Refresh current status / retry initialization | Guarded E snapshot with visible busy/error outcome. Initial recovery does not depend on a service or session that failed to exist. |
| Directory select and topic | Store selected `{id,qualificationRevision}` and whitelist topic. No request yet. |
| Consent | Explicit checkbox for selected fictional practitioner and ONLY demand category; cleared on selection/revision/role changes. No health/chat/address/order disclosure. |
| Inquire | Client role, current selected qualified target; `{action:'inquire',practitionerId,qualificationRevision,topic,expectedVersion:0}`. Do NOT include consent:false, which the strict schema rejects. |
| Invite | Same plus `{action:'invite',...,consent:true}` with explicit consent. |
| Accept / reject | Practitioner role, own pending invitation; `{action,id,expectedVersion}` from displayed row. |
| Revoke / end relationship | Authorized client or practitioner, current pending/accepted row; exact row ID/version. |
| Answer / close inquiry | Authorized role and valid current state, exact ID/version; original synthetic reply semantics unchanged. |
| All / pending / active / closed | Display-only filtered projection; never fetch another user's records or create request authority. |
| Public article cards | Escaped plain-text whitelist: ID, fictional owner label/display name, title/body, source URL/title/date, applicability, limitations and explicit synthetic label. URL is text, not fetch or clickable external navigation. No profile/credential/review queue/private demand leakage. |

Do not bring back raw fixture revise/revoke/restore/failure controls. Qualification changes now go through author saves/withdrawals and the reviewer workflow below. Failure injection belongs only to offline tests.

## 8. Actual SP registration, publication, and review actions

Use `K.forms.decorate/open/present/sample/save/request/review` unchanged. Form validation follows the pinned contract, including its source-date rule; no silent timezone or state-machine edit in this UI batch. Pure helpers take cloned presentation data and the controller's clock.

Author registration editor preserves all seven fields: displayName, biography, practiceScope, credentialType, credentialIssuer, credentialJurisdiction, credentialClaimRef. Credentials must be fictional `SYNTHETIC-...` references, no upload/input for real certificate files, identifiers or contact information. Article editor preserves title, plain body, HTTPS source URL text, source title/date, applicability and limitations. Every save requires explicit acknowledgment that all content is synthetic. Sample-fill is optional and visibly fictional; it does not tick acknowledgment or submit.

| Visible control | Path / exact condition |
| --- | --- |
| Edit/new registration | Author only; `forms.open(data,fullContext,'profile',null,serial)`, original version/registration epoch frozen. |
| Save registration/article | `forms.save(form,now)` → explicit field errors or strict request payload; create one key and E request using form's original full context. Validation errors cause no write. |
| Submit registration | `forms.request(...,'submitProfile')`; saved DRAFT only and no unsaved editor changes. |
| Withdraw registration | Exact current version/epoch, visible confirmation, state not withdrawn/revoked. Result can invalidate relationships and publications together. |
| New/edit article | Own author and saved profile required; target ID exact or new-record null. Keep complete field values and original version. |
| Submit article | Own draft, current eligible profile, no other submitted article; no unsaved editor changes. |
| Publish article | Exact approved article with current content+qualification binding and current eligible profile; label “本机合成发布”. |
| Withdraw article | Exact displayed own article version and epoch, state not withdrawn. |
| Reviewer approve / reject registration | Reviewer only; `forms.review(data,owner,'approved' or 'rejected')`, exact owner, applicationId, expectedVersion, contentRevision, registration epoch. |
| Reviewer revoke qualification | Reviewer only, currently approved profile; same exact target shape and explicit confirmation. |
| Reviewer approve article | Reviewer only; exact owner/articleId/version/contentRevision/epoch AND profileVersion/profileContentRevision. No “approve latest” lookup and no unsupported article-reject button. |

Reviewer confirmation captures the exact target, full context and render/modal serial BEFORE the dialog. On confirmation recheck all of them and consume the dialog once. Double click, repeated callback, old owner/target selection or role change cannot submit a second command or review a different record. Dialog text states this is fictional workflow approval and no real professional verification occurs.

Every form open/close/replace advances an independent form serial and the applicable render/action token. DOM input/ack/sample/save/cancel all carry the exact serial AND render token. Old events from article A cannot edit or cancel article B, even when both were clean. A retained draft's context is never replaced by a refresh context. Unsaved-form submit/publish asks to save or cancel first; destructive withdrawal can ask once while retaining draft until confirmed final presentation.

Bounded journal usage may show count/MAX_EVENTS from the same-revision root check. Capacity/unsupported old archive errors keep existing bytes and editor, explain inability to add operations, and offer safe refresh/settings navigation. Never auto-prune journal, silently reinitialize or claim an absent old snapshot is recoverable.

## 9. Failure and recovery matrix

- Before service/login exists: independent visible retry button with Page/attempt token; both roots communicate the same error. Retry retires only the failed attempt, creates one service/session and installs no duplicate listener. Old retry buttons and late initialization callbacks cannot act.
- Before commit: preserve editor/request values; display exact validation/conflict/storage error. A fresh user operation needs deliberate refresh/reopen when its context is stale; no automatic rebase.
- Unknown commit/ACK: E controls own original retry, observation-only current-record check and Stop. Show “结果未确认”; do not say not saved or fabricate durable proof. Reconciliation can compare frozen context and observed journal/target identifiers but is labeled observation only; it cannot call snapshot while unknown or grant new write authority.
- Confirmed commit but Page/context/deadline retired: do not paint old results; classify known committed honestly. Pagehide suppresses feedback entirely. Visible live page keeps read-only submitted draft and a safe refresh path.
- Final render failure: keep old DOM/editor/base; do not claim refresh/successful presentation. Retry uses visible controls independent of the invalid view ticket. Last-read failures during both initialization and refresh are explicit tests, not assumed covered by one initial read.
- Corrupt/missing branch: no reset-as-repair, no automatic new seed/import. E remains responsible for validated recovery and page-only alternative. PC must be usable again when E rechecks successfully; it cannot wait forever on an already-resolved readiness promise or rely on a stale failed attempt.
- Memory mode: same domain flow, clearly page-only, no v2 import or persistent writes. Navigating/reloading loses the temporary account and pending identity.

## 10. Offline acceptance gates (implementation counts not yet claimed)

Tests execute real new PC/PU/SP handlers and actual E+B+kernel with injected deterministic locks/storage/time. Disabled controls must be unclickable in the harness, reflected dataset attributes must work, and forms must dispatch actual input/change/submit/click. Direct controller tests supplement, not replace, handler chains.

| ID | Required executable evidence |
| --- | --- |
| P01 | Scope: three new JS only; C1 eight hashes, B three, old24/support19/12HTML and six native pins/frozen HEAD unchanged. Initial plan preflight confirms three absent. |
| P02 | Actual proposed ordered student graph, all three tails and two roots, no old A/B; missing/wrong/duplicate/late tails or root cannot adopt/write. Clearly not actual HTML activation. |
| P03 | One controller/actor across both panels; default client; five personas, strict role/projection isolation; raw service/session/lease absent from public exports. Accepted author→client and reviewer→author switches synchronously remove old private content in both roots, even when the new snapshot fails; cancelled switches preserve it. |
| P04 | End-to-end actual fields: author save → submit → reviewer approve → directory available → client inquiry/invite → practitioner answer/accept → client sees private relationship → revoke. Strict inquiry omits consent key. |
| P05 | Full article new/save/edit → submit → exact reviewer approval → author publish → client public card → withdraw; two owners and multiple article IDs never cross-target. |
| P06 | Exact approval race: concurrent content/qualification edits, owner switch, two submitted targets across owners; stale dialog/duplicate confirmation rejects without new write. No unsupported article-reject control. |
| P07 | Qualification edit/withdraw/revoke/expiry atomically removes eligibility, private authorization and article visibility; later reapproval does not resurrect old authorization/publication. |
| P08 | All seven fields/errors, plain text escaping, synthetic-reference/ack rules, valid source dates, optional sample does not authorize save; no real sensitive fields/network/source navigation. |
| P09 | Same-epoch revision overtake between result and final paint in two real controllers; both panels refuse stale view, preserve draft/base. Initial/success/replay/snapshot variants. |
| P10 | Deadline crossing at lock wait and after result before final render, including reviewer/publication and all-already-expired view. Clock rollback fails safely. Timer invalidation issues no write. |
| P11 | Dirty and clean editor refresh; cancel preserves exactly, success retires old form, final read/DOM failure preserves form. Explicitly throw on the SECOND root commit after the first changed: both original DOM node identities, runtime input/checkbox values, form serial/base and single delegated listeners must be restored. Last-read failure initial and successful write cannot fake mounted/saved presentation. |
| P12 | Old input/ack/sample/save/cancel/dialog from article A after article B open, including clean A; no mutation or discard of B. Also rapid double clicks/form replacement/role change. |
| P13 | Lost ACK for request/review/relation and snapshot normalization: original key/input/full intent retained, E blocks every other writer, original retry at most once, new epoch refuses old retry; Stop restores safe refresh only. |
| P14 | Committed result overtaken by one foreign health/commerce write retains submitted draft and truthful outcome. Changed row values or matching observation is not receipt proof. |
| P15 | Pagehide/logout/role/reset/restore/corrupt-read during queued operation: old continuation/old finally cannot alter new session/UI or commit through a retired guard. Both panels retire synchronously; accepted author→client and reviewer→author with failed new snapshot cannot restore old actor/private content. Transient same-role read failure retains a non-authorized same-role draft separately from identity retirement. |
| P16 | Initialization failure before service/login, at snapshot, final root read and renderer: visible local retry recovers once without duplicate listeners; retry after E Stop/recheck, retired retry ignored. |
| P17 | Qualification revision selection change/disappearance clears selection+consent; original frozen pending request not rewritten. Malicious inherited topic keys reach actual validation with otherwise valid intent. |
| P18 | Post-reload persistent registration/articles/relations recover through same v3 branch; complete preexisting health/commerce untouched. Memory mode never persists and announces loss. |
| P19 | Public cards contain only explicit article/name whitelist, no credentials/reviewer/private-demand/health/order data; reviewer has empty relationship arrays, author sees only self. |
| P20 | Journal capacity/corrupt/unsupported archive failure preserves bytes and draft; no raw-A workaround, auto-reset/prune, duplicate seed/import, or invented rollback. |
| P21 | App-owned back/links/hash/tab/close/role changes share one dirty/pending gate; native departure remains best-effort. Focus/selection retained where modeled, no claim of browser/mobile visual verification. |
| P22 | Full C1 runtime tests retain original assertions; A/B111 unchanged; old Web19 fixed bundle regression. C1's historical “C2 files absent” phase test runs only against its archived pre-C2 fixture or remains labeled historical; new scope test verifies actual C2. No assertion is silently loosened. |

Final evidence must pin all three runtime hashes, commands/results, actual handler mounts and pre-fix probes if any. An unmodified reviewer runs independent race/privacy/initialization tests before limited C2 acceptance. C3 then separately switches all twelve real HTMLs and tests navigation/assets/source graph; actual browser/mobile/WeChat remains a further unmet gate.

## 11. Rollback boundaries

C2 is inactive additions only; C1 source archive and existing HTML/runtime remain usable. Keep new source/evidence archive after review. Synthetic injected test storage is not an actual user's browser backup. No HTML/runtime has yet migrated a user's storage; no real account or health record is involved.

Once C3 is later admitted, old HTML must use only its old v2 namespace while v3 bytes/checkpoint remain intact. Neither source Git/tar rollback nor a banned unsafe raw-A downgrade is a complete data rollback tool. Exact-cutoff Web restoration UI and safe native data backup/restore remain explicit later work. Never claim nonexistent snapshots or merge later v2 changes automatically.

## 12. Candidate 2 review clarification

The independent candidate-1 review requested two implementation rules now made explicit: accepted identity changes retire and remove both panels' old private content before any await, even if the replacement initialization fails; a second-root presentation exception must restore original DOM nodes/runtime values/tickets rather than reconstructed HTML. P03/P11/P15 include those executable assertions. No runtime scope has expanded.
